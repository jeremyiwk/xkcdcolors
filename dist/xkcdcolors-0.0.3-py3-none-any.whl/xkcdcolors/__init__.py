"""
xkcdcolors
~~~~~~~~~~

Makes two objects, list and dict, that contain the colors from this website :https://xkcd.com/color/rgb/
"""
